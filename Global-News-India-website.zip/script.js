const data = {
  world: [
    ["विश्व", "अंतरराष्ट्रीय समाचारों के लिए आपका नया सेक्शन", "यहाँ सत्यापित और मौलिक समाचार सारांश प्रकाशित किए जाएँगे।"],
    ["World", "Global News Updates", "English-language global news will appear here."]
  ],
  india: [
    ["भारत", "भारत की ताज़ा और महत्वपूर्ण खबरें", "विश्वसनीय स्रोतों से जानकारी लेकर अपनी भाषा में समाचार तैयार किए जाएँगे।"],
    ["India", "India News", "Verified India news will appear here."]
  ],
  business: [
    ["बिज़नेस", "बिज़नेस और अर्थव्यवस्था की खबरें", "मार्केट, कंपनियों और अर्थव्यवस्था से जुड़ी खबरें।"]
  ],
  tech: [
    ["टेक्नोलॉजी", "टेक की दुनिया की नई खबरें", "AI, मोबाइल, इंटरनेट और डिजिटल दुनिया की खबरें।"]
  ]
};
function render(id, items){
  document.getElementById(id+"Cards").innerHTML = items.map(x =>
    `<article class="card"><div class="category">${x[0]}</div><h3>${x[1]}</h3><p>${x[2]}</p></article>`
  ).join("");
}
render("world",data.world); render("india",data.india); render("business",data.business); render("tech",data.tech);

let english=false;
document.getElementById("langBtn").onclick=()=>{
  english=!english;
  document.documentElement.lang=english?"en":"hi";
  document.getElementById("langBtn").textContent=english?"हिंदी":"English";
  document.querySelector(".logo").innerHTML=english?"🌍 Global News India":"🌍 Global News India";
  document.querySelector(".nav-row").innerHTML=english
    ? `<a href="#">Home</a><a href="#world">World</a><a href="#india">India</a><a href="#business">Business</a><a href="#tech">Technology</a><a href="#sports">Sports</a><a href="#entertainment">Entertainment</a><a href="#science">Science</a>`
    : `<a href="#">होम</a><a href="#world">विश्व</a><a href="#india">भारत</a><a href="#business">बिज़नेस</a><a href="#tech">टेक्नोलॉजी</a><a href="#sports">खेल</a><a href="#entertainment">मनोरंजन</a><a href="#science">विज्ञान</a>`;
  document.getElementById("headline").textContent=english?"Top news from India and around the world":"दुनिया और भारत की प्रमुख खबरें एक ही जगह";
  document.getElementById("summary").textContent=english?"Your new bilingual news website homepage.":"यह आपकी नई द्विभाषी न्यूज़ वेबसाइट का शुरुआती होमपेज है।";
};
document.getElementById("searchBtn").onclick=()=>alert("Search feature अगले चरण में जोड़ा जाएगा।");